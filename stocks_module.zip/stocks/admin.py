from django.contrib import admin
from .models import Stock, Watchlist, Trade, Account

@admin.register(Stock)
class StockAdmin(admin.ModelAdmin):
    list_display = ('symbol', 'name', 'current_price', 'updated_at')
    search_fields = ('symbol', 'name')

@admin.register(Watchlist)
class WatchlistAdmin(admin.ModelAdmin):
    list_display = ('user', 'name', 'created_at')
    search_fields = ('user__username', 'name')

@admin.register(Trade)
class TradeAdmin(admin.ModelAdmin):
    list_display = ('user', 'stock', 'trade_type', 'quantity', 'price', 'timestamp')
    list_filter = ('trade_type',)
    search_fields = ('user__username', 'stock__symbol')

@admin.register(Account)
class AccountAdmin(admin.ModelAdmin):
    list_display = ('user', 'virtual_balance', 'total_pnl')
    search_fields = ('user__username',)
