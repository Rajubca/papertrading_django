# Stocks Django App (module)

This "stocks" Django app contains:
- Models: Stock, Account, Watchlist, Trade
- samco_client.py: wrapper for stocknotebridge SDK (get_quote, multi_quote)
- trading_utils.py: FIFO helpers, portfolio aggregation
- views.py: watchlist, stock detail, modify_watchlist (AJAX), place_trade (AJAX), portfolio, orders
- templates: base.html, watchlist.html, stock_detail.html, portfolio.html, orders.html
- admin.py: Admin registrations

## Installation
1. Copy the `stocks` folder into your Django project.
2. Add `'stocks.apps.StocksConfig'` to `INSTALLED_APPS` in settings.py.
3. Ensure Django templates settings include the app templates.
4. Run:
   ```
   pip install -r requirements.txt
   python manage.py makemigrations stocks
   python manage.py migrate
   ```
5. Configure stocknotebridge SDK per your provider; set `SAMCO_SESSION_TOKEN` in your env if available.

## Notes
- The app expects the stocknotebridge Python SDK to be installed and importable at `snapi_py_client.snapi_bridge`.
- If the SDK is not present, the client functions will return None; the views fall back to stored `Stock.current_price` when available.
- AJAX forms use the csrftoken cookie; ensure CSRF middleware is enabled.

